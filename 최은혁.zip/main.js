var swiper = new Swiper('.sec2_swiper', {
    navigation: {
        nextEl: '.next2',
        prevEl: '.prev2',
    },
});
